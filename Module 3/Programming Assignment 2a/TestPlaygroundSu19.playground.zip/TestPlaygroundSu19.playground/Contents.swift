//: Playground - noun: a place where people can play

import UIKit

var str : String
str = "Hello, world!"
print(str)
var str1 = "mystring"
print(str1)
str = "Second value"
print(str)
str1 = "a new hope"
print(str1)
var x = 5
var y : Int
y = x
print(y)
var x1: UInt
x1 = 27
print(x1)
var x2: UInt16
x2 = 0xaf
print(x2)
x2 = 0b1001
print(x2)
var f1 = 1.00026
var f2 : Double
f2 = f1
print(f2)
f2 = Double(x1)
print(f2)
x1 = UInt(x2)
f2 = f1 + 3
print(f2)
x1 = UInt(f1 + 3)
print(x1)
let x3 = 5
print(x3)
var x4 = x3 + 2
print(x4)
var c: Character = "x"
var condition:Bool = true
var myNumbers = [5,7,9]
myNumbers[2]
myNumbers[0]
myNumbers.append(11)
myNumbers.removeAll()
myNumbers = [2,4,6,8,10]
myNumbers[2...3]
myNumbers.removeSubrange(3...4)
myNumbers.remove(at: 1)
myNumbers
var myStrings = ["these", "are", "my", "strings"]
myStrings[2]
var myDictionary = ["these":1, "are":2, "my":3, "strings":4]
myDictionary["are"]
var myDictionary2:[String:Int]
myDictionary.removeValue(forKey: "are")
myDictionary
import UIKit
var myns : NSString
myns = "abc"
var x5: Int?
x5 = nil
x5 = myDictionary["foo"]
x5 = myDictionary["strings"]
y = x5!
print(y)
var x6: Int!
x6 = myDictionary["these"]
y = x6
//x5??5





