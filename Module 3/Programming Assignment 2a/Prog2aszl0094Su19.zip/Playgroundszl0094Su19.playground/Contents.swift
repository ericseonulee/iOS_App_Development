//: Playground - noun: a place where people can play

import UIKit
//var months:Int = 72
//var apr = 4.4
//var principle = 20000

func paymentCalculator(_ months: Double, _ apr: Double, _ principle: Double)-> Double {
    var payment = 0.0
    payment = (apr * principle) / (1 - pow(1 + (apr / 100), (-1 * months)))
    
    return payment
}

print(paymentCalculator(72, (4.4 / 12), 20000))
print(paymentCalculator(30, 5, 150000))
