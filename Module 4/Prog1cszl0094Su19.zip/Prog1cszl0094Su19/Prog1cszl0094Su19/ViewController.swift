//
//  ViewController.swift
//  Prog1cszl0094Su19
//
//  Created by user155599 on 6/12/19.
//  Copyright © 2019 Eric Lee. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    let bamaImage = #imageLiteral(resourceName: "bama")
    let auburnImage = #imageLiteral(resourceName: "auburn")
    let maxLabel = UILabel()
    let minLabel = UILabel()
    
    @IBOutlet weak var bamaView: UIImageView!
    @IBOutlet weak var auburnView: UIImageView!
    
    @IBOutlet weak var slider: UISlider!

    @IBAction func slider(_ sender: UISlider) {
        let value = sender.value
        bamaView.alpha = CGFloat(value)
        auburnView.alpha = CGFloat(slider.maximumValue - value)
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        slider.value = 0.5
        
        
        bamaView.image = bamaImage
        bamaView.alpha = 0.5
        
        auburnView.image = auburnImage
        auburnView.alpha = 0.5
        
    }

    func calcSlider() {
        
    }


}
