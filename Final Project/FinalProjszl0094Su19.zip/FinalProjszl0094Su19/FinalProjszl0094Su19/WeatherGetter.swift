//
//  WeatherGetter.swift
//  FinalProjszl0094Su19
//
//  Created by user155599 on 7/17/19.
//  Copyright © 2019 Eric Lee. All rights reserved.
//

import Foundation

protocol WeatherGetterDelegate {
    func didGetWeather(weather: Weather)
    func didNotGetWeather(error: NSError)
}

class WeatherGetter {
    private let openWeatherMapBaseURL = "https://api.openweathermap.org/data/2.5/weather"
    private let openWeatherMapAPIKey = "4e03dda691d80b21c7a5d47d978508cd"
    
    private let delegate: WeatherGetterDelegate
    
    init(delegate: WeatherGetterDelegate) {
        self.delegate = delegate
    }
    
    // this free api does not accepts city names with space in it such as New York.
    // Also, there is no option for me to choose between cities with the same name. Therefore, entering "Auburn" will not necessarily return Auburn in Alabama.
    // recommend to test with cities with unique names such as Seoul, Tokyo, etc.
    func getWeatherByCity(city: String) {
        let weatherRequestURL = URL(string: "\(openWeatherMapBaseURL)?APPID=\(openWeatherMapAPIKey)&q=\(city)")!
        getWeather(weatherRequestURL: weatherRequestURL as NSURL)
    }
    
    private func getWeather (weatherRequestURL: NSURL) {
        let session = URLSession.shared
        
        let dataTask = session.dataTask(with: weatherRequestURL as URL) {
            (data: Data?, response: URLResponse?, error: Error?) in
            if let networkError = error {
                self.delegate.didNotGetWeather(error: networkError as NSError)
            }
            else {
                print("Success")
                do {
                    
                    let weatherData = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as! Dictionary<AnyHashable, AnyObject>
                    
                    let weather = Weather(weatherData: weatherData as! [String : AnyObject])
                    
                    self.delegate.didGetWeather(weather: weather)
                    /*print("Date and time: \(weather["dt"]!)")
                    print("City: \(weather["name"]!)")
                    
                    print("Longitude: \(weather["coord"]!["lon"]!!)")
                    print("Latitude: \(weather["coord"]!["lat"]!!)")
                    
                    print("Weather ID: \((weather["weather"]![0]!as![String: AnyObject])["id"]!)")
                    print("Weather main: \((weather["weather"]![0]!as![String: AnyObject])["main"]!)")
                    print("Weather description: \((weather["weather"]![0]!as![String: AnyObject])["description"]!)")
                    print("Weather icon ID: \((weather["weather"]![0]!as![String: AnyObject])["icon"]!)")
                    
                    print("Temperature: \(weather["main"]!["temp"]!!)")
                    print("Humidity: \(weather["main"]!["humidity"]!!)")
                    print("Pressure: \(weather["main"]!["pressure"]!!)")
                    
                    print("Cloud cover: \(weather["clouds"]!["all"]!!)")
                    
                    print("Wind direction: \(weather["wind"]!["deg"]!!) degrees")
                    print("Wind speed: \(weather["wind"]!["speed"]!!)")
                    
                    print("Country: \(weather["sys"]!["country"]!!)")
                    print("Sunrise: \(weather["sys"]!["sunrise"]!!)")
                    print("Sunset: \(weather["sys"]!["sunset"]!!)")*/
                }
                catch let jsonError as NSError {
                    self.delegate.didNotGetWeather(error: jsonError)
                    //print("JSON error description: \(jsonError.description)")
                }
                //print("Raw Data:\n\(data!)\n")
                //let dataString = String(data: data!, encoding: String.Encoding.utf8)
                //print("Human-readable data:\n\(dataString!)")
            }
        }
        dataTask.resume()
    }
}
