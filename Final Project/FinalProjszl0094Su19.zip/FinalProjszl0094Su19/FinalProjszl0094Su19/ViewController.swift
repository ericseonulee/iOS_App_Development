//
//  ViewController.swift
//  FinalProjszl0094Su19
//
//  Created by user155599 on 7/17/19.
//  Copyright © 2019 Eric Lee. All rights reserved.
//

import UIKit

class ViewController: UIViewController, WeatherGetterDelegate, UITextFieldDelegate {
    var rawTempC = 0.0
    var rawTempF = 0.0
    
    func didGetWeather(weather: Weather) {
        rawTempC = weather.convertToCelsius
        rawTempF = weather.convertToFahrenheit
        DispatchQueue.main.async() {
            self.tempControl.selectedSegmentIndex = 0
            self.tempControl.isEnabled = true
            self.cityLabel.text = weather.city
            self.weatherLabel.text = weather.weatherDescription
            self.weatherIcon.image = UIImage(named: weather.weatherIconID)
            self.temperatureLabel.text = "\(Int(round(weather.convertToFahrenheit)))°"
            self.cloudCoverLabel.text = "\(weather.cloudCover)%"
            self.windLabel.text = "\(weather.windSpeed) m/s"
            
            if let rain = weather.rainfallInLast3Hours {
                self.rainLabel.text = "\(rain) mm"
            }
            else {
                self.rainLabel.text = "None"
            }
            
            self.humidityLabel.text = "\(weather.humidity)%"
        }    }
    
    func didNotGetWeather(error: NSError) {
        DispatchQueue.main.async() {
            //self.showsimplealert(title: "Can't get the weather", message: "The weather service isn't responding.")
        }
        print("didNotGetWeather error: \(error)")    }
    
    @IBOutlet weak var weatherIcon: UIImageView!
    @IBOutlet weak var tempControl: UISegmentedControl!
    @IBOutlet weak var cityLabel: UILabel!
    @IBOutlet weak var weatherLabel: UILabel!
    @IBOutlet weak var temperatureLabel: UILabel!
    @IBOutlet weak var cloudCoverLabel: UILabel!
    @IBOutlet weak var windLabel: UILabel!
    @IBOutlet weak var rainLabel: UILabel!
    @IBOutlet weak var humidityLabel: UILabel!

    @IBOutlet weak var cityNameField: UITextField!
    @IBOutlet weak var getWeatherButton: UIButton!
    
    var weather: WeatherGetter!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        weather = WeatherGetter(delegate: self)
        
        tempControl.selectedSegmentIndex = 0
        cityLabel.text = "Weather App"
        weatherLabel.text = ""
        temperatureLabel.text = ""
        cloudCoverLabel.text = ""
        windLabel.text = ""
        rainLabel.text = ""
        humidityLabel.text = ""
        cityNameField.text = ""
        cityNameField.placeholder = "Enter city name"
        cityNameField.delegate = self
        cityNameField.enablesReturnKeyAutomatically = true
        getWeatherButton.isEnabled = false
        tempControl.isEnabled = false
    }

    @IBAction func convertTemp(_ sender: Any) {
        switch tempControl.selectedSegmentIndex {
        case 0:
            temperatureLabel.text = "\(Int(round(rawTempF)))°"
        case 1:
            temperatureLabel.text = "\(Int(round(rawTempC)))°"
        default:
            break
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func getWeatherButtonPressed(_ sender: UIButton) {
        guard let text = cityNameField.text, !text.isEmpty else {
            return
        }
        weather.getWeatherByCity(city: cityNameField.text!)
    }
    
    func textField(_ textField: UITextField,
                   shouldChangeCharactersIn range: NSRange,
                   replacementString string: String) -> Bool {
        let currentText = textField.text ?? ""
        let prospectiveText = (currentText as NSString).replacingCharacters(
            in: range,
            with: string)
        getWeatherButton.isEnabled = prospectiveText.characters.count > 0
        print("Count: \(prospectiveText.characters.count)")
        return true
    }
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        textField.text = ""
        tempControl.isEnabled = false
        getWeatherButton.isEnabled = false
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        getWeatherButtonPressed(getWeatherButton)
        return true
    }
}

