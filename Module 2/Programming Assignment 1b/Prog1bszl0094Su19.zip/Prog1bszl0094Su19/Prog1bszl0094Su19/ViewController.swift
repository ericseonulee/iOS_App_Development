//
//  ViewController.swift
//  Prog1bszl0094Su19
//
//  Created by Eric Lee on 5/30/19.
//  Copyright © 2019 Eric Lee. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var imageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        imageView.image = #imageLiteral(resourceName: "SEC_new_logo")
    }
    
    @IBAction func auburnButton(_ sender: UIView) {
        imageView.image = #imageLiteral(resourceName: "543px-Auburn_Tigers_logo.svg")
    }
    
    @IBAction func secButton(_ sender: UIView) {
        imageView.image = #imageLiteral(resourceName: "SEC_new_logo")
    }
    
    @IBAction func bamaButton(_ sender: UIView) {
        imageView.image = #imageLiteral(resourceName: "alabama_crimson_tide_2004-pres")
    }

}

